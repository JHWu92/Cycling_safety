function create_account() {
	window.location = "create_account.html";
}
