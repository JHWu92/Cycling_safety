<?php
session_start();    //Start session

$db_name = "cyclings_vid1";
$con=mysqli_connect("localhost","cyclings_jiahui","@2n54a=@]ZQ4", $db_name);

if(mysqli_connect_errno())
{
    echo"failed to connect to mysql:".mysqli_connect_error();
}
else{
    $gender=$_POST['gender'];
    $email = $_SESSION["Email"];
    
    $sql="UPDATE Users SET gender='$gender' WHERE email= '$email'";
    $result=mysqli_query($con, $sql);

    if(mysqli_connect_errno())
    {
        echo"failed to connect to mysql:".mysqli_connect_error();
    }
    else{
        header("Location: http://cyclingsafety.umd.edu/rate-vid.html"); 
        return true;
    }
}
?>